import base64

files = ['banner.png','img1.png','img2.png','img3.png','img4.png','img5.png','img6.png']
imgs = {}
for f in files:
    with open(f, 'rb') as fh:
        imgs[f] = 'data:image/png;base64,' + base64.b64encode(fh.read()).decode('ascii')

html = '''<!DOCTYPE html>
<html lang="tr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>AnkaraAI Events &#8212; Intelligence-Powered Event Portal</title>
<meta name="description" content="Ankara yapay zeka destekli etkinlik haberleri portali.">
<link rel="stylesheet" href="style.css">
</head>
<body>
<aside class="sidebar">
  <div class="logo">
    <div class="logo-icon">&#129504;</div>
    <div>
      <div class="logo-text">AnkaraAI</div>
      <div class="logo-sub">Events Portal</div>
    </div>
  </div>
  <nav>
    <div class="nav-label">Main Menu</div>
    <div class="nav-item active"><span class="icon">&#9702;</span> Dashboard <span class="nav-badge">3</span></div>
    <div class="nav-item"><span class="icon">&#127891;</span> Akademik Paneller</div>
    <div class="nav-item"><span class="icon">&#128295;</span> Workshops</div>
    <div class="nav-item"><span class="icon">&#127908;</span> Konferanslar</div>
    <div class="nav-item"><span class="icon">&#9889;</span> Hackathonlar</div>
    <div class="nav-label" style="margin-top:12px">Ke&#351;fet</div>
    <div class="nav-item"><span class="icon">&#128506;</span> Etkinlik Haritas&#305;</div>
    <div class="nav-item"><span class="icon">&#128197;</span> Takvim</div>
    <div class="nav-item"><span class="icon">&#128278;</span> Kaydedilenler</div>
    <div class="nav-item"><span class="icon">&#128202;</span> Analitik</div>
    <div class="nav-label" style="margin-top:12px">Sistem</div>
    <div class="nav-item"><span class="icon">&#9881;</span> Ayarlar</div>
  </nav>
  <div class="sidebar-footer">
    <div class="user-mini">
      <div class="avatar-sm">AY</div>
      <div class="user-info">
        <div class="user-name">Ay&#351;e Y&#305;ld&#305;z</div>
        <div class="user-role">Edit&#246;r &middot; Pro Plan</div>
      </div>
      <span style="color:var(--muted);cursor:pointer">&#8943;</span>
    </div>
  </div>
</aside>

<div class="main">
  <header>
    <div style="display:flex;flex-direction:column">
      <div style="font-size:18px;font-weight:800">Dashboard</div>
      <div style="font-size:12px;color:var(--muted)">Cumartesi, 19 Nisan 2026</div>
    </div>
    <div class="search-wrap" style="margin-left:28px">
      <span class="search-icon">&#128269;</span>
      <input type="text" placeholder="Etkinlik, konum veya konu&#351;mac&#305; ara&#8230; (K&#305;z&#305;lay, METU, AI, Robotik)" id="main-search">
    </div>
    <div class="header-actions">
      <div class="icon-btn" title="Bildirimler">&#128276;<span class="notif-dot"></span></div>
      <div class="icon-btn" title="Filtreler">&#9889;</div>
      <div class="icon-btn" title="Takvim">&#128197;</div>
      <div class="avatar" title="Profil">AY</div>
    </div>
  </header>

  <div class="content">
    <!-- STATS -->
    <div class="stats-row">
      <div class="stat-card">
        <div class="stat-icon blue">&#128203;</div>
        <div>
          <div class="stat-val">248</div>
          <div class="stat-label">Aktif Etkinlikler</div>
          <div class="stat-trend up">&#8593; 12% bu hafta</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon purple">&#129302;</div>
        <div>
          <div class="stat-val">1.4K</div>
          <div class="stat-label">AI &#214;zetlendi</div>
          <div class="stat-trend up">&#8593; 34% bu ay</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon green">&#128101;</div>
        <div>
          <div class="stat-val">18.7K</div>
          <div class="stat-label">Kay&#305;tl&#305; Kullan&#305;c&#305;</div>
          <div class="stat-trend up">&#8593; 8% b&#252;y&#252;me</div>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon amber">&#128205;</div>
        <div>
          <div class="stat-val">42</div>
          <div class="stat-label">Ankara Mekân&#305;</div>
          <div class="stat-trend up">&#8593; 5 yeni mekan</div>
        </div>
      </div>
    </div>

    <!-- BANNER -->
    <div class="banner-section">
      <div class="banner-label"><span class="live-dot"></span> &#214;ne &#199;&#305;kan Etkinlik Haberleri</div>
      <div class="banner" id="banner">
        <img id="banner-img" src="BANNER_SRC" alt="&#214;ne &#231;&#305;kan etkinlik">
        <div class="banner-overlay"></div>
        <div class="banner-content">
          <div class="banner-tag" id="banner-tag">&#128308; Canl&#305; Haber &middot; Konferans</div>
          <div class="banner-title" id="banner-title">Ankara Uluslararas&#305; Yapay Zeka ve Teknoloji Zirvesi 2026</div>
          <div class="banner-meta">
            <span id="bdate">&#128197; 22&#8211;24 Nisan 2026</span>
            <span id="bloc">&#128205; Bilkent Kongre Merkezi, &#199;ankaya</span>
            <span id="bspk">&#127908; Dr. Emre Kaya, Prof. Selin &#214;zdemir +18</span>
          </div>
          <div style="margin-top:14px;max-width:560px;font-size:13px;color:rgba(226,232,240,.75);line-height:1.65">
            <span style="color:#a78bfa;font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:.5px">&#10022; AI &#214;zet &middot; </span>
            <span id="bsummary">Bu y&#305;l&#305;n en b&#252;y&#252;k yapay zeka zirvesi, 30&#39;dan fazla uluslararas&#305; konu&#351;mac&#305; ve 5.000+ kat&#305;l&#305;mc&#305;yla Bilkent Kongre Merkezi&#39;nde kap&#305;lar&#305;n&#305; a&#231;&#305;yor. Makine &#246;&#287;renmesi, b&#252;y&#252;k dil modelleri ve T&#252;rkiye&#39;nin dijital d&#246;n&#252;&#351;&#252;m stratejisi &#246;ne &#231;&#305;kan ba&#351;l&#305;klar aras&#305;nda yer al&#305;yor.</span>
          </div>
        </div>
        <div class="banner-arrow banner-arrow-l" onclick="changeBanner(-1)">&#8249;</div>
        <div class="banner-arrow" onclick="changeBanner(1)">&#8250;</div>
        <div class="banner-dots">
          <div class="dot active" onclick="goToBanner(0)"></div>
          <div class="dot" onclick="goToBanner(1)"></div>
          <div class="dot" onclick="goToBanner(2)"></div>
        </div>
      </div>
    </div>

    <!-- EVENTS GRID -->
    <div>
      <div class="section-header">
        <div class="section-title"><span></span> Son AI-&#214;zetlenmi&#351; Etkinlikler</div>
        <div style="display:flex;gap:8px;align-items:center">
          <div class="chip active" onclick="filterCards(this,'All')">T&#252;m&#252;</div>
          <div class="chip" onclick="filterCards(this,'Konferans')">Konferans</div>
          <div class="chip" onclick="filterCards(this,'Workshop')">Workshop</div>
          <div class="chip" onclick="filterCards(this,'Panel')">Panel</div>
          <button class="view-all">T&#252;m&#252;n&#252; G&#246;r &#8594;</button>
        </div>
      </div>

      <div class="events-grid" id="events-grid">
        <!-- Card 1 -->
        <div class="event-card" data-cat="Panel">
          <img class="card-img" src="IMG1_SRC" alt="AI Panel">
          <div class="card-body">
            <div class="card-tags"><span class="tag blue">Panel</span><span class="tag purple">Yapay Zeka</span></div>
            <div class="card-headline">ODT&#220; Akademik Yapay Zeka Paneli: B&#252;y&#252;k Dil Modelleri ve Etik</div>
            <div class="ai-badge">AI &#214;zet</div>
            <div class="ai-summary">ODT&#220; BM b&#246;l&#252;m&#252;n&#252;n d&#252;zenledi&#287;i bu panelde GPT-4o, Gemini ve yerli dil modelleri kar&#351;&#305;la&#351;t&#305;rmal&#305; olarak ele al&#305;nacak. Akademisyenler etik AI kullan&#305;m&#305; &#252;zerine tart&#305;&#351;acak.</div>
          </div>
          <div class="card-footer">
            <div class="card-date">&#128197; 25 Nisan 2026</div>
            <div class="location-badge">&#128205; &#199;ankaya &middot; ODT&#220;</div>
          </div>
        </div>

        <!-- Card 2 -->
        <div class="event-card" data-cat="Workshop">
          <img class="card-img" src="IMG2_SRC" alt="Workshop">
          <div class="card-body">
            <div class="card-tags"><span class="tag green">Workshop</span><span class="tag amber">Giri&#351;im</span></div>
            <div class="card-headline">Startup Kulu&#231;ka Merkezi: &#220;r&#252;n-Pazar Uyumu At&#246;lyesi</div>
            <div class="ai-badge">AI &#214;zet</div>
            <div class="ai-summary">KOSGEB destekli bu at&#246;lye, erken a&#351;ama startup kurucular&#305;n&#305; hedef al&#305;yor. M&#252;&#351;teri ke&#351;fi, MVP geli&#351;tirme ve yat&#305;r&#305;mc&#305; sunum teknikleri uygulamal&#305; olarak &#246;&#287;retilecek.</div>
          </div>
          <div class="card-footer">
            <div class="card-date">&#128197; 27 Nisan 2026</div>
            <div class="location-badge">&#128205; K&#305;z&#305;lay &middot; Kolektif</div>
          </div>
        </div>

        <!-- Card 3 -->
        <div class="event-card" data-cat="Konferans">
          <img class="card-img" src="IMG3_SRC" alt="Konferans">
          <div class="card-body">
            <div class="card-tags"><span class="tag blue">Konferans</span><span class="tag purple">Teknoloji</span></div>
            <div class="card-headline">Ankara Smart City Konferans&#305;: Ak&#305;ll&#305; &#350;ehir Altyap&#305;lar&#305;</div>
            <div class="ai-badge">AI &#214;zet</div>
            <div class="ai-summary">Belediye ve &#246;zel sekt&#246;r i&#351; birli&#287;iyle d&#252;zenlenen konferansta IoT sens&#246;rleri, ak&#305;ll&#305; ula&#351;&#305;m sistemleri ve Ankara&#39;n&#305;n 2030 dijital d&#246;n&#252;&#351;&#252;m plan&#305; sunulacak.</div>
          </div>
          <div class="card-footer">
            <div class="card-date">&#128197; 29 Nisan 2026</div>
            <div class="location-badge">&#128205; K&#305;z&#305;lay &middot; ATO</div>
          </div>
        </div>

        <!-- Card 4 -->
        <div class="event-card" data-cat="Workshop">
          <img class="card-img" src="IMG4_SRC" alt="Hackathon">
          <div class="card-body">
            <div class="card-tags"><span class="tag purple">Hackathon</span><span class="tag green">48 Saat</span></div>
            <div class="card-headline">TechAnkara Hackathon 2026: Sa&#287;l&#305;k Teknolojileri</div>
            <div class="ai-badge">AI &#214;zet</div>
            <div class="ai-summary">48 saatlik bu maratonda ekipler sa&#287;l&#305;k verisi analizi ve te&#351;his destekli AI &#231;&#246;z&#252;mleri geli&#351;tirerek 150.000 TL &#246;d&#252;l havuzu i&#231;in yar&#305;&#351;acak.</div>
          </div>
          <div class="card-footer">
            <div class="card-date">&#128197; 2&#8211;3 May&#305;s 2026</div>
            <div class="location-badge">&#128205; Tunal&#305; &middot; Impact Hub</div>
          </div>
        </div>

        <!-- Card 5 -->
        <div class="event-card" data-cat="Konferans">
          <img class="card-img" src="IMG5_SRC" alt="Zirve">
          <div class="card-body">
            <div class="card-tags"><span class="tag amber">Zirve</span><span class="tag blue">&#350;ehir Planlama</span></div>
            <div class="card-headline">Ankara 2030 Vizyon Zirvesi: S&#252;rd&#252;r&#252;lebilir B&#252;y&#252;me</div>
            <div class="ai-badge">AI &#214;zet</div>
            <div class="ai-summary">&#350;ehir planc&#305;lar&#305;, mimarlar ve belediye y&#246;neticilerinin bir araya geldi&#287;i zirvede Ankara&#39;n&#305;n &#231;evreci ula&#351;&#305;m ve ye&#351;il alan projeleri masaya yat&#305;r&#305;lacak.</div>
          </div>
          <div class="card-footer">
            <div class="card-date">&#128197; 5 May&#305;s 2026</div>
            <div class="location-badge">&#128205; Ulus &middot; B&#252;y&#252;k&#351;ehir</div>
          </div>
        </div>

        <!-- Card 6 -->
        <div class="event-card" data-cat="Panel">
          <img class="card-img" src="IMG6_SRC" alt="Seminer">
          <div class="card-body">
            <div class="card-tags"><span class="tag green">Seminer</span><span class="tag blue">Akademik</span></div>
            <div class="card-headline">Bilkent &#220;niversitesi Kuantum Bili&#351;im Semineri</div>
            <div class="ai-badge">AI &#214;zet</div>
            <div class="ai-summary">Prof. Dr. Ahmet &#199;elik liderli&#287;inde y&#252;r&#252;t&#252;len bu seminer, kuantum devre tasar&#305;m&#305; ve kriptografi uygulamalar&#305;n&#305; lisans ve y&#252;ksek lisans &#246;&#287;rencilerine tan&#305;t&#305;yor.</div>
          </div>
          <div class="card-footer">
            <div class="card-date">&#128197; 8 May&#305;s 2026</div>
            <div class="location-badge">&#128205; Bilkent &middot; &#220;niversite</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
var banners=[
  {tag:"&#128308; Canl&#305; Haber &middot; Konferans",title:"Ankara Uluslararas&#305; Yapay Zeka ve Teknoloji Zirvesi 2026",date:"&#128197; 22&#8211;24 Nisan 2026",loc:"&#128205; Bilkent Kongre Merkezi, &#199;ankaya",summary:"Bu y&#305;l&#305;n en b&#252;y&#252;k yapay zeka zirvesi, 30'dan fazla uluslararas&#305; konu&#351;mac&#305; ve 5.000+ kat&#305;l&#305;mc&#305;yla Bilkent Kongre Merkezi'nde kap&#305;lar&#305;n&#305; a&#231;&#305;yor. Makine &#246;&#287;renmesi, b&#252;y&#252;k dil modelleri ve T&#252;rkiye'nin dijital d&#246;n&#252;&#351;&#252;m stratejisi &#246;ne &#231;&#305;kan ba&#351;l&#305;klar aras&#305;nda yer al&#305;yor."},
  {tag:"&#127942; &#214;ne &#199;&#305;kan &middot; Yar&#305;&#351;ma",title:"T&#252;rkiye Ulusal Robotik &#350;ampiyonas&#305; &#8212; Ankara Finalleri",date:"&#128197; 28 Nisan 2026",loc:"&#128205; Ankara Arena, Etlik",summary:"22 &#351;ehirden 140 tak&#305;m&#305;n yar&#305;&#351;aca&#287;&#305; ulusal robotik &#351;ampiyonas&#305;nda insans&#305; robot, otonom ara&#231; ve drone kategorilerinde m&#252;cadele ya&#351;anacak. Finalistler uluslararas&#305; bilete hak kazanacak."},
  {tag:"&#127908; Yak&#305;nda &middot; Sa&#287;l&#305;k",title:"MedTech Ankara: Dijital Sa&#287;l&#305;k ve AI Kongresi",date:"&#128197; 30 Nisan 2026",loc:"&#128205; Gazi &#220;niversitesi Kongre Salonu",summary:"T&#305;p doktorlar&#305;, yaz&#305;l&#305;m m&#252;hendisleri ve sa&#287;l&#305;k yat&#305;r&#305;mc&#305;lar&#305;n&#305; bulu&#351;turan MedTech Ankara, tan&#305; yapay zekas&#305; ve hastane otomasyon sistemleri &#252;zerine kapsaml&#305; bir program sunuyor."}
];
var current=0;
var dots=document.querySelectorAll('.dot');
function updateBanner(){
  var b=banners[current];
  document.getElementById('banner-tag').innerHTML=b.tag;
  document.getElementById('banner-title').innerHTML=b.title;
  document.getElementById('bdate').innerHTML=b.date;
  document.getElementById('bloc').innerHTML=b.loc;
  document.getElementById('bsummary').innerHTML=b.summary;
  dots.forEach(function(d,i){d.classList.toggle('active',i===current);});
}
function changeBanner(dir){current=(current+dir+banners.length)%banners.length;updateBanner();}
function goToBanner(i){current=i;updateBanner();}
setInterval(function(){changeBanner(1);},6000);

function filterCards(el,cat){
  document.querySelectorAll('.chip').forEach(function(c){c.classList.remove('active');});
  el.classList.add('active');
  document.querySelectorAll('.event-card').forEach(function(card){
    var match=cat==='All'||card.dataset.cat===cat;
    card.style.display=match?'flex':'none';
  });
}
document.getElementById('main-search').addEventListener('input',function(){
  var q=this.value.toLowerCase();
  document.querySelectorAll('.event-card').forEach(function(card){
    card.style.display=(!q||card.textContent.toLowerCase().includes(q))?'flex':'none';
  });
});
document.querySelectorAll('.nav-item').forEach(function(item){
  item.addEventListener('click',function(){
    document.querySelectorAll('.nav-item').forEach(function(i){i.classList.remove('active');});
    item.classList.add('active');
  });
});
</script>
</body>
</html>'''

# Inject base64 image sources
html = html.replace('BANNER_SRC', imgs['banner.png'])
html = html.replace('IMG1_SRC', imgs['img1.png'])
html = html.replace('IMG2_SRC', imgs['img2.png'])
html = html.replace('IMG3_SRC', imgs['img3.png'])
html = html.replace('IMG4_SRC', imgs['img4.png'])
html = html.replace('IMG5_SRC', imgs['img5.png'])
html = html.replace('IMG6_SRC', imgs['img6.png'])

with open('index_final.html', 'w', encoding='utf-8') as f:
    f.write(html)

print('Done. Size:', round(len(html)/1024/1024, 2), 'MB')
