import base64, re

files = ['banner.png','img1.png','img2.png','img3.png','img4.png','img5.png','img6.png']

with open('index.html', 'r', encoding='utf-8') as f:
    html = f.read()

for fname in files:
    try:
        with open(fname, 'rb') as img:
            data = base64.b64encode(img.read()).decode('ascii')
        uri = 'data:image/png;base64,' + data
        html = html.replace('src="' + fname + '"', 'src="' + uri + '"')
        print('Embedded', fname)
    except Exception as e:
        print('Error with', fname, e)

with open('index_final.html', 'w', encoding='utf-8') as f:
    f.write(html)

print('Done, size:', len(html) // 1024, 'KB')
